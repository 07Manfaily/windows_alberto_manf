import React, { useState, useEffect } from 'react';
import './App.css';

const API_BASE_URL = 'http://localhost:5000/api';

function App() {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [quizStarted, setQuizStarted] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const startQuiz = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/quiz/start`);
      const data = await response.json();
      
      if (data.success) {
        setQuestions(data.questions);
        setQuizStarted(true);
      } else {
        alert('Erreur lors du chargement du quiz');
      }
    } catch (error) {
      console.error('Erreur:', error);
      alert('Erreur de connexion au serveur');
    }
    setLoading(false);
  };

  const handleAnswer = (questionId, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const nextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const submitQuiz = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/quiz/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ answers })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setResults(data);
        setQuizCompleted(true);
      } else {
        alert('Erreur lors de la soumission');
      }
    } catch (error) {
      console.error('Erreur:', error);
      alert('Erreur de connexion au serveur');
    }
    setLoading(false);
  };

  const restartQuiz = () => {
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setAnswers({});
    setQuizStarted(false);
    setQuizCompleted(false);
    setResults(null);
  };

  const currentQuestion = questions[currentQuestionIndex];

  if (quizCompleted && results) {
    return (
      <div className="app">
        <div className="quiz-container">
          <div className="results-section">
            <h1>Résultats du Quiz UX Designer</h1>
            
            <div className="score-display">
              <div className="score-circle">
                <div className="score-number">{results.percentage}%</div>
                <div className="score-label">Score final</div>
              </div>
              
              <div className="score-details">
                <h2 className={`level level-${results.level.toLowerCase().replace(' ', '-')}`}>
                  {results.level}
                </h2>
                <p className="score-message">{results.message}</p>
                <p className="score-fraction">
                  {results.score} / {results.total_questions} réponses correctes
                </p>
              </div>
            </div>

            <div className="detailed-results">
              <h3>Détail des réponses :</h3>
              {results.detailed_results.map((result, index) => (
                <div key={result.question_id} className={`result-item ${result.is_correct ? 'correct' : 'incorrect'}`}>
                  <div className="result-header">
                    <span className="question-number">Question {index + 1}</span>
                    <span className={`result-status ${result.is_correct ? 'correct' : 'incorrect'}`}>
                      {result.is_correct ? '✓ Correct' : '✗ Incorrect'}
                    </span>
                  </div>
                  <div className="result-question">{result.question}</div>
                  <div className="result-explanation">{result.explanation}</div>
                </div>
              ))}
            </div>

            <button onClick={restartQuiz} className="restart-btn">
              Recommencer le quiz
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!quizStarted) {
    return (
      <div className="app">
        <div className="quiz-container">
          <div className="welcome-section">
            <h1>Quiz de Recrutement UX Designer</h1>
            <div className="welcome-content">
              <p>Bienvenue dans ce quiz conçu pour évaluer vos connaissances en UX Design.</p>
              
              <div className="quiz-info">
                <h3>Informations sur le quiz :</h3>
                <ul>
                  <li>10 questions sur les fondamentaux de l'UX Design</li>
                  <li>Questions à choix unique (QCU) et à choix multiples (QCM)</li>
                  <li>Durée estimée : 10-15 minutes</li>
                  <li>Score affiché à la fin avec explications détaillées</li>
                </ul>
              </div>

              <div className="instructions">
                <h3>Instructions :</h3>
                <ul>
                  <li>Lisez attentivement chaque question</li>
                  <li>Pour les QCM, plusieurs réponses peuvent être correctes</li>
                  <li>Vous pouvez naviguer entre les questions</li>
                  <li>Vérifiez vos réponses avant de soumettre</li>
                </ul>
              </div>

              <button 
                onClick={startQuiz} 
                disabled={loading}
                className="start-btn"
              >
                {loading ? 'Chargement...' : 'Commencer le Quiz'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="app">
        <div className="quiz-container">
          <div className="loading">Chargement des questions...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <div className="quiz-container">
        <div className="quiz-header">
          <div className="progress-bar">
            <div 
              className="progress-fill"
              style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
          <div className="question-counter">
            Question {currentQuestionIndex + 1} sur {questions.length}
          </div>
        </div>

        <div className="question-section">
          <h2 className="question-title">{currentQuestion.question}</h2>
          <div className="question-type">
            {currentQuestion.type === 'qcm' ? 
              'Plusieurs réponses possibles' : 
              'Une seule réponse possible'
            }
          </div>

          <div className="options-list">
            {currentQuestion.options.map((option, optionIndex) => (
              <label key={optionIndex} className="option-label">
                <input
                  type={currentQuestion.type === 'qcm' ? 'checkbox' : 'radio'}
                  name={`question-${currentQuestion.id}`}
                  value={optionIndex}
                  checked={
                    currentQuestion.type === 'qcm' 
                      ? (answers[currentQuestion.id] || []).includes(optionIndex)
                      : answers[currentQuestion.id] === optionIndex
                  }
                  onChange={(e) => {
                    if (currentQuestion.type === 'qcm') {
                      const currentAnswers = answers[currentQuestion.id] || [];
                      const newAnswers = e.target.checked
                        ? [...currentAnswers, optionIndex]
                        : currentAnswers.filter(a => a !== optionIndex);
                      handleAnswer(currentQuestion.id, newAnswers);
                    } else {
                      handleAnswer(currentQuestion.id, optionIndex);
                    }
                  }}
                />
                <span className="option-text">{option}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="navigation-section">
          <button 
            onClick={previousQuestion}
            disabled={currentQuestionIndex === 0}
            className="nav-btn prev-btn"
          >
            ← Précédent
          </button>

          {currentQuestionIndex === questions.length - 1 ? (
            <button 
              onClick={submitQuiz}
              disabled={loading}
              className="submit-btn"
            >
              {loading ? 'Soumission...' : 'Terminer le Quiz'}
            </button>
          ) : (
            <button 
              onClick={nextQuestion}
              className="nav-btn next-btn"
            >
              Suivant →
            </button>
          )}
        </div>

        <div className="answers-summary">
          <h4>Progression :</h4>
          <div className="question-dots">
            {questions.map((_, index) => (
              <span 
                key={index}
                className={`question-dot ${
                  answers[questions[index].id] !== undefined ? 'answered' : ''
                } ${index === currentQuestionIndex ? 'current' : ''}`}
                onClick={() => setCurrentQuestionIndex(index)}
              >
                {index + 1}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
