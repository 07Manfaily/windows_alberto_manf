# 🚀 Guide de Démarrage Rapide - Quiz UX Designer

## Installation Express (Linux/Mac)

```bash
# 1. Extraire le projet
unzip quiz-ux-designer.zip
cd quiz-ux-designer

# 2. Lancer l'application (tout automatique)
chmod +x start.sh
./start.sh
```

## Installation Manuelle

### Backend (Terminal 1)
```bash
cd backend
pip install flask flask-cors
python app.py
```

### Frontend (Terminal 2)
```bash
cd frontend
npm install
npm start
```

## 🌐 Accès à l'Application

- **Quiz UX Designer** : http://localhost:3000
- **API Backend** : http://localhost:5000

## 🧪 Test Rapide

```bash
# Tester l'API
python test_api.py
```

## 📝 Personnalisation

### Ajouter des Questions
Modifiez le tableau `quiz_questions` dans `backend/app.py`

### Changer les Couleurs
Modifiez les variables CSS dans `frontend/src/App.css`

## 🎯 Questions Incluses

1. Fondamentaux UX Design
2. Recherche utilisateur (QCM)
3. Wireframing
4. Méthodes de recherche (QCM)
5. Personas
6. Principes d'interface (QCM)
7. Tests A/B
8. Outils UX (QCM)
9. Affordance
10. Design Thinking (QCM)

## 🏆 Système de Score

- **80%+** : Excellent
- **60-79%** : Bon
- **40-59%** : Moyen
- **<40%** : À améliorer

---

✅ **Prêt à recruter vos UX Designers !**
