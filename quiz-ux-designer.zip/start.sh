#!/bin/bash

# Script de démarrage pour l'application Quiz UX Designer
# Ce script lance le backend Flask et le frontend React

echo "🚀 Démarrage de l'application Quiz UX Designer..."

# Couleurs pour l'affichage
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Fonction pour vérifier si un port est libre
check_port() {
    if lsof -Pi :$1 -sTCP:LISTEN -t >/dev/null ; then
        return 1
    else
        return 0
    fi
}

# Vérification des prérequis
echo -e "${BLUE}📋 Vérification des prérequis...${NC}"

# Vérifier Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python3 n'est pas installé${NC}"
    exit 1
fi

# Vérifier Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js n'est pas installé${NC}"
    exit 1
fi

# Vérifier npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ npm n'est pas installé${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Tous les prérequis sont installés${NC}"

# Vérifier les ports
if ! check_port 5000; then
    echo -e "${RED}❌ Le port 5000 (backend) est déjà utilisé${NC}"
    exit 1
fi

if ! check_port 3000; then
    echo -e "${RED}❌ Le port 3000 (frontend) est déjà utilisé${NC}"
    exit 1
fi

# Installation des dépendances backend
echo -e "${YELLOW}📦 Installation des dépendances backend...${NC}"
cd backend
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt

# Démarrage du backend en arrière-plan
echo -e "${BLUE}🔧 Démarrage du backend Flask...${NC}"
python app.py &
BACKEND_PID=$!

# Attendre que le backend soit prêt
sleep 3

# Installation des dépendances frontend
echo -e "${YELLOW}📦 Installation des dépendances frontend...${NC}"
cd ../frontend
if [ ! -d "node_modules" ]; then
    npm install
fi

# Démarrage du frontend
echo -e "${BLUE}🎨 Démarrage du frontend React...${NC}"
npm start &
FRONTEND_PID=$!

# Affichage des informations
echo -e "${GREEN}"
echo "🎉 Application démarrée avec succès !"
echo ""
echo "📱 Frontend (React): http://localhost:3000"
echo "🔧 Backend (Flask):  http://localhost:5000"
echo ""
echo "Pour arrêter l'application, appuyez sur Ctrl+C"
echo -e "${NC}"

# Fonction de nettoyage pour arrêter les processus
cleanup() {
    echo -e "${YELLOW}🛑 Arrêt de l'application...${NC}"
    kill $BACKEND_PID 2>/dev/null
    kill $FRONTEND_PID 2>/dev/null
    echo -e "${GREEN}✅ Application arrêtée${NC}"
    exit 0
}

# Capturer Ctrl+C pour nettoyer proprement
trap cleanup INT

# Attendre que l'utilisateur arrête l'application
wait
