from flask import Flask, jsonify, request
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app)  # Permet les requêtes depuis le frontend React

# Base de données des questions UX (en mémoire pour cet exemple)
quiz_questions = [
    {
        "id": 1,
        "question": "Qu'est-ce que l'UX Design ?",
        "type": "qcu",  # Question à Choix Unique
        "options": [
            "La conception de l'interface utilisateur uniquement",
            "L'expérience globale qu'a un utilisateur avec un produit",
            "Le design graphique d'une application",
            "La programmation frontend"
        ],
        "correct_answer": 1,
        "explanation": "L'UX Design concerne l'expérience globale de l'utilisateur, pas seulement l'interface."
    },
    {
        "id": 2,
        "question": "Quels sont les piliers principaux de l'UX Design ? (Plusieurs réponses possibles)",
        "type": "qcm",  # Question à Choix Multiples
        "options": [
            "Utilisabilité",
            "Accessibilité", 
            "Couleurs attrayantes",
            "Désirabilité",
            "Taille des polices"
        ],
        "correct_answers": [0, 1, 3],  # Indices des bonnes réponses
        "explanation": "Les piliers sont l'utilisabilité, l'accessibilité et la désirabilité."
    },
    {
        "id": 3,
        "question": "Que signifie 'wireframe' en UX Design ?",
        "type": "qcu",
        "options": [
            "Une maquette haute fidélité",
            "Un schéma structural d'une page ou interface",
            "Un prototype interactif",
            "Une charte graphique"
        ],
        "correct_answer": 1,
        "explanation": "Un wireframe est un schéma structural qui montre l'organisation des éléments."
    },
    {
        "id": 4,
        "question": "Quelles méthodes font partie de la recherche utilisateur ?",
        "type": "qcm",
        "options": [
            "Interviews utilisateurs",
            "Tests d'utilisabilité",
            "Choix des couleurs",
            "Personas",
            "Sondages"
        ],
        "correct_answers": [0, 1, 3, 4],
        "explanation": "Les interviews, tests, personas et sondages sont des méthodes de recherche utilisateur."
    },
    {
        "id": 5,
        "question": "Qu'est-ce qu'un persona en UX ?",
        "type": "qcu",
        "options": [
            "Un vrai utilisateur du produit",
            "Un archétype d'utilisateur basé sur des recherches",
            "Un designer de l'équipe",
            "Un testeur QA"
        ],
        "correct_answer": 1,
        "explanation": "Un persona est un archétype fictif représentant un groupe d'utilisateurs réels."
    },
    {
        "id": 6,
        "question": "Quels principes guident un bon design d'interface ?",
        "type": "qcm",
        "options": [
            "Consistance",
            "Feedback utilisateur",
            "Complexité maximale",
            "Hiérarchie visuelle",
            "Prévention des erreurs"
        ],
        "correct_answers": [0, 1, 3, 4],
        "explanation": "La consistance, le feedback, la hiérarchie et la prévention d'erreurs sont essentiels."
    },
    {
        "id": 7,
        "question": "Que teste un test A/B ?",
        "type": "qcu",
        "options": [
            "La performance technique",
            "Deux versions d'un élément pour voir laquelle performe mieux",
            "La sécurité de l'application",
            "La compatibilité navigateur"
        ],
        "correct_answer": 1,
        "explanation": "Un test A/B compare deux versions pour mesurer leur efficacité relative."
    },
    {
        "id": 8,
        "question": "Quels outils sont couramment utilisés en UX Design ?",
        "type": "qcm",
        "options": [
            "Figma",
            "Sketch",
            "Microsoft Word",
            "Adobe XD",
            "Miro"
        ],
        "correct_answers": [0, 1, 3, 4],
        "explanation": "Figma, Sketch, Adobe XD et Miro sont des outils UX populaires."
    },
    {
        "id": 9,
        "question": "Qu'est-ce que l'affordance en design ?",
        "type": "qcu",
        "options": [
            "Le prix d'un produit",
            "La capacité d'un objet à suggérer sa propre utilisation",
            "La rapidité d'exécution",
            "La beauté esthétique"
        ],
        "correct_answer": 1,
        "explanation": "L'affordance est la capacité d'un objet à suggérer intuitivement son usage."
    },
    {
        "id": 10,
        "question": "Quelles phases composent le processus de Design Thinking ?",
        "type": "qcm",
        "options": [
            "Empathie",
            "Définition",
            "Décoration",
            "Idéation",
            "Prototype et Test"
        ],
        "correct_answers": [0, 1, 3, 4],
        "explanation": "Les phases sont : Empathie, Définition, Idéation, Prototype et Test."
    }
]

@app.route('/api/quiz/start', methods=['GET'])
def start_quiz():
    """Retourne toutes les questions du quiz (sans les réponses correctes)"""
    questions_for_frontend = []
    
    for q in quiz_questions:
        question_data = {
            "id": q["id"],
            "question": q["question"],
            "type": q["type"],
            "options": q["options"]
        }
        questions_for_frontend.append(question_data)
    
    return jsonify({
        "success": True,
        "questions": questions_for_frontend,
        "total_questions": len(quiz_questions)
    })

@app.route('/api/quiz/submit', methods=['POST'])
def submit_quiz():
    """Évalue les réponses et retourne le score"""
    user_answers = request.json.get('answers', {})
    
    if not user_answers:
        return jsonify({"success": False, "error": "Aucune réponse fournie"}), 400
    
    score = 0
    detailed_results = []
    
    for question in quiz_questions:
        question_id = str(question["id"])
        user_answer = user_answers.get(question_id)
        
        if question["type"] == "qcu":
            # Question à choix unique
            is_correct = user_answer == question["correct_answer"]
            if is_correct:
                score += 1
                
        elif question["type"] == "qcm":
            # Question à choix multiples
            if user_answer is None:
                user_answer = []
            
            # Convertir en ensemble pour comparaison
            user_set = set(user_answer) if isinstance(user_answer, list) else set()
            correct_set = set(question["correct_answers"])
            
            is_correct = user_set == correct_set
            if is_correct:
                score += 1
        
        # Ajouter les détails pour le feedback
        detailed_results.append({
            "question_id": question["id"],
            "question": question["question"],
            "user_answer": user_answer,
            "correct_answer": question.get("correct_answer") or question.get("correct_answers"),
            "is_correct": is_correct,
            "explanation": question["explanation"],
            "type": question["type"]
        })
    
    total_questions = len(quiz_questions)
    percentage = round((score / total_questions) * 100, 1)
    
    # Déterminer le niveau
    if percentage >= 80:
        level = "Excellent"
        message = "Félicitations ! Vous maîtrisez très bien les concepts UX."
    elif percentage >= 60:
        level = "Bon"
        message = "Bon travail ! Vous avez une bonne compréhension de l'UX."
    elif percentage >= 40:
        level = "Moyen"
        message = "Pas mal ! Il y a encore quelques concepts à approfondir."
    else:
        level = "À améliorer"
        message = "Il serait bénéfique de revoir les fondamentaux de l'UX Design."
    
    return jsonify({
        "success": True,
        "score": score,
        "total_questions": total_questions,
        "percentage": percentage,
        "level": level,
        "message": message,
        "detailed_results": detailed_results
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """Point de contrôle pour vérifier que l'API fonctionne"""
    return jsonify({"status": "OK", "message": "Quiz API is running"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
