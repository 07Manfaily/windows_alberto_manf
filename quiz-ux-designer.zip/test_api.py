#!/usr/bin/env python3
"""
Script de test pour l'API du quiz UX Designer
Teste les endpoints et affiche les résultats
"""

import requests
import json
import time

API_BASE_URL = 'http://localhost:5000/api'

def test_health_endpoint():
    """Test du endpoint de santé"""
    print("🔍 Test du endpoint de santé...")
    try:
        response = requests.get(f'{API_BASE_URL}/health')
        if response.status_code == 200:
            print("✅ Health check: OK")
            print(f"   Réponse: {response.json()}")
            return True
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Erreur lors du health check: {e}")
        return False

def test_quiz_start():
    """Test du démarrage du quiz"""
    print("\n🔍 Test du démarrage du quiz...")
    try:
        response = requests.get(f'{API_BASE_URL}/quiz/start')
        if response.status_code == 200:
            data = response.json()
            print("✅ Démarrage du quiz: OK")
            print(f"   Nombre de questions: {data['total_questions']}")
            print(f"   Première question: {data['questions'][0]['question'][:50]}...")
            return data
        else:
            print(f"❌ Démarrage du quiz failed: {response.status_code}")
            return None
    except Exception as e:
        print(f"❌ Erreur lors du démarrage: {e}")
        return None

def test_quiz_submit(questions_data):
    """Test de la soumission du quiz"""
    print("\n🔍 Test de la soumission du quiz...")
    
    # Créer des réponses de test (quelques bonnes, quelques mauvaises)
    test_answers = {
        "1": 1,      # Bonne réponse pour question 1
        "2": [0, 1], # Réponse partielle pour question 2 (QCM)
        "3": 1,      # Bonne réponse pour question 3
        "4": [0, 1], # Réponse partielle pour question 4 (QCM)
        "5": 1,      # Bonne réponse pour question 5
        "6": [0, 1], # Réponse partielle pour question 6 (QCM)
        "7": 1,      # Bonne réponse pour question 7
        "8": [0, 1], # Réponse partielle pour question 8 (QCM)
        "9": 1,      # Bonne réponse pour question 9
        "10": [0, 1] # Réponse partielle pour question 10 (QCM)
    }
    
    try:
        response = requests.post(
            f'{API_BASE_URL}/quiz/submit',
            headers={'Content-Type': 'application/json'},
            data=json.dumps({'answers': test_answers})
        )
        
        if response.status_code == 200:
            data = response.json()
            print("✅ Soumission du quiz: OK")
            print(f"   Score: {data['score']}/{data['total_questions']} ({data['percentage']}%)")
            print(f"   Niveau: {data['level']}")
            print(f"   Message: {data['message']}")
            
            # Afficher quelques détails des résultats
            print(f"   Nombre de réponses correctes: {sum(1 for r in data['detailed_results'] if r['is_correct'])}")
            print(f"   Nombre de réponses incorrectes: {sum(1 for r in data['detailed_results'] if not r['is_correct'])}")
            
            return data
        else:
            print(f"❌ Soumission du quiz failed: {response.status_code}")
            print(f"   Réponse: {response.text}")
            return None
    except Exception as e:
        print(f"❌ Erreur lors de la soumission: {e}")
        return None

def main():
    """Fonction principale de test"""
    print("🧪 Test de l'API Quiz UX Designer")
    print("=" * 50)
    
    # Test 1: Health check
    if not test_health_endpoint():
        print("\n❌ Le serveur ne répond pas. Assurez-vous que le backend est démarré.")
        return
    
    # Test 2: Démarrage du quiz
    questions_data = test_quiz_start()
    if not questions_data:
        print("\n❌ Impossible de récupérer les questions.")
        return
    
    # Test 3: Soumission du quiz
    results = test_quiz_submit(questions_data)
    if not results:
        print("\n❌ Impossible de soumettre le quiz.")
        return
    
    print("\n🎉 Tous les tests sont passés avec succès !")
    print("\n📋 Résumé des tests:")
    print("   ✅ Health check")
    print("   ✅ Récupération des questions")
    print("   ✅ Soumission et évaluation")
    
    print(f"\n🎯 Score de test obtenu: {results['percentage']}% ({results['level']})")

if __name__ == "__main__":
    main()
