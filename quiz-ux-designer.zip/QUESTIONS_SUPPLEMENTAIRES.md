# Questions UX Supplémentaires

Voici des questions additionnelles que vous pouvez ajouter au quiz selon vos besoins :

## Questions Techniques

```python
{
    "id": 11,
    "question": "Qu'est-ce que le Material Design ?",
    "type": "qcu",
    "options": [
        "Un type de matériau pour les prototypes physiques",
        "Un système de design créé par Google",
        "Une méthode de recherche utilisateur",
        "Un outil de wireframing"
    ],
    "correct_answer": 1,
    "explanation": "Material Design est le système de design développé par Google."
}

{
    "id": 12,
    "question": "Quels sont les principes de l'accessibilité web (WCAG) ?",
    "type": "qcm",
    "options": [
        "Perceptible",
        "Utilisable", 
        "Esthétique",
        "Compréhensible",
        "Robuste"
    ],
    "correct_answers": [0, 1, 3, 4],
    "explanation": "Les 4 principes WCAG sont : Perceptible, Utilisable, Compréhensible et Robuste."
}

{
    "id": 13,
    "question": "Que signifie MVP dans le contexte UX ?",
    "type": "qcu",
    "options": [
        "Most Valuable Player",
        "Minimum Viable Product",
        "Maximum Visual Prototype",
        "Multi-Version Platform"
    ],
    "correct_answer": 1,
    "explanation": "MVP signifie Minimum Viable Product - la version minimale d'un produit avec les fonctionnalités essentielles."
}
```

## Questions Méthodologiques

```python
{
    "id": 14,
    "question": "Quelles méthodes sont utilisées pour l'idéation en UX ?",
    "type": "qcm",
    "options": [
        "Brainstorming",
        "Mind mapping",
        "Tests A/B",
        "Crazy 8s",
        "Storyboarding"
    ],
    "correct_answers": [0, 1, 3, 4],
    "explanation": "Le brainstorming, mind mapping, Crazy 8s et storyboarding sont des méthodes d'idéation. Les tests A/B sont pour l'évaluation."
}

{
    "id": 15,
    "question": "Qu'est-ce qu'un journey map ?",
    "type": "qcu",
    "options": [
        "Une carte géographique des utilisateurs",
        "Un plan du site web",
        "Une visualisation du parcours utilisateur",
        "Un organigramme de l'équipe"
    ],
    "correct_answer": 2,
    "explanation": "Un journey map visualise l'expérience complète de l'utilisateur avec un produit ou service."
}
```

## Questions Avancées

```python
{
    "id": 16,
    "question": "Quels outils sont utilisés pour la recherche quantitative en UX ?",
    "type": "qcm",
    "options": [
        "Heatmaps",
        "Analytics web",
        "Interviews",
        "Sondages",
        "Card sorting"
    ],
    "correct_answers": [0, 1, 3],
    "explanation": "Heatmaps, analytics et sondages fournissent des données quantitatives. Interviews et card sorting sont qualitatifs."
}

{
    "id": 17,
    "question": "Que teste principalement un test d'utilisabilité ?",
    "type": "qcu",
    "options": [
        "La performance technique",
        "L'esthétique du design",
        "La facilité d'utilisation",
        "La sécurité de l'application"
    ],
    "correct_answer": 2,
    "explanation": "Un test d'utilisabilité évalue principalement la facilité d'utilisation d'un produit."
}

{
    "id": 18,
    "question": "Quels éléments composent une bonne hiérarchie visuelle ?",
    "type": "qcm",
    "options": [
        "Taille des éléments",
        "Couleur et contraste",
        "Animations complexes",
        "Espacement",
        "Typographie"
    ],
    "correct_answers": [0, 1, 3, 4],
    "explanation": "La hiérarchie visuelle repose sur la taille, couleur/contraste, espacement et typographie."
}
```

## Questions Sectorielles

```python
{
    "id": 19,
    "question": "Qu'est-ce que l'UX Writing ?",
    "type": "qcu",
    "options": [
        "Écrire des articles sur l'UX",
        "Rédiger le contenu des interfaces utilisateur",
        "Documenter les processus UX",
        "Créer des guides utilisateur"
    ],
    "correct_answer": 1,
    "explanation": "L'UX Writing consiste à rédiger les textes des interfaces pour guider et rassurer l'utilisateur."
}

{
    "id": 20,
    "question": "Quels sont les avantages du design système ?",
    "type": "qcm",
    "options": [
        "Cohérence visuelle",
        "Réduction des coûts de développement",
        "Complexité accrue",
        "Scalabilité",
        "Collaboration améliorée"
    ],
    "correct_answers": [0, 1, 3, 4],
    "explanation": "Un design système apporte cohérence, efficacité, scalabilité et collaboration. Il réduit la complexité."
}
```

## Instructions pour Ajouter ces Questions

1. Ouvrez `backend/app.py`
2. Ajoutez les nouvelles questions au tableau `quiz_questions`
3. Redémarrez le serveur Flask
4. Les nouvelles questions apparaîtront automatiquement dans le quiz

## Conseils pour Créer de Nouvelles Questions

- **Variez les types** : Alternez QCU et QCM
- **Niveaux différents** : Débutant, intermédiaire, avancé
- **Domaines variés** : Recherche, design, outils, méthodes
- **Explications claires** : Aidez les candidats à apprendre
- **Réponses piège** : Testez la vraie compréhension
