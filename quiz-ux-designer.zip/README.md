# Quiz UX Designer - Application de Recrutement

Une application web complète pour évaluer les compétences UX des candidats, développée avec React.js (frontend) et Flask/Python (backend).

## 🎯 Fonctionnalités

- **10 questions** couvrant les fondamentaux de l'UX Design
- **Questions QCM et QCU** pour une évaluation complète
- **Interface moderne et responsive** avec React.js
- **Navigation intuitive** entre les questions
- **Score détaillé** avec explications
- **API REST** robuste avec Flask
- **Feedback en temps réel** sur les performances

## 📋 Prérequis

- Node.js (version 14 ou supérieure)
- Python 3.7 ou supérieure
- npm ou yarn

## 🚀 Installation et Démarrage

### 1. Backend (Flask/Python)

```bash
# Se placer dans le dossier backend
cd backend

# Installer les dépendances Python
pip install -r requirements.txt

# Démarrer le serveur Flask
python app.py
```

Le backend sera accessible sur `http://localhost:5000`

### 2. Frontend (React.js)

```bash
# Ouvrir un nouveau terminal et se placer dans le dossier frontend
cd frontend

# Installer les dépendances Node.js
npm install

# Démarrer l'application React
npm start
```

Le frontend sera accessible sur `http://localhost:3000`

## 🏗️ Structure du Projet

```
quiz-ux-designer/
├── backend/
│   ├── app.py              # Application Flask principale
│   └── requirements.txt    # Dépendances Python
├── frontend/
│   ├── public/
│   │   └── index.html     # Template HTML
│   ├── src/
│   │   ├── App.js         # Composant React principal
│   │   ├── App.css        # Styles CSS
│   │   ├── index.js       # Point d'entrée React
│   │   └── index.css      # Styles globaux
│   └── package.json       # Dépendances Node.js
└── README.md              # Ce fichier
```

## 🎮 Utilisation

1. **Démarrer le quiz** : Cliquez sur "Commencer le Quiz"
2. **Répondre aux questions** : 
   - QCU : Une seule réponse possible
   - QCM : Plusieurs réponses possibles
3. **Navigation** : Utilisez les boutons Précédent/Suivant
4. **Soumission** : Cliquez sur "Terminer le Quiz" à la dernière question
5. **Résultats** : Consultez votre score et les explications détaillées

## 📊 Questions Couvertes

Le quiz évalue les connaissances sur :
- Fondamentaux de l'UX Design
- Méthodes de recherche utilisateur
- Wireframing et prototypage
- Tests d'utilisabilité
- Design Thinking
- Outils UX populaires
- Principes d'interface utilisateur

## 🔧 API Endpoints

### Backend Flask

- `GET /api/quiz/start` : Récupère les questions du quiz
- `POST /api/quiz/submit` : Soumet les réponses et calcule le score
- `GET /api/health` : Vérification de l'état de l'API

## 💡 Personnalisation

### Ajouter des Questions

Modifiez le tableau `quiz_questions` dans `backend/app.py` :

```python
{
    "id": 11,
    "question": "Votre nouvelle question ?",
    "type": "qcu",  # ou "qcm"
    "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
    "correct_answer": 1,  # pour QCU
    # ou
    "correct_answers": [0, 2],  # pour QCM
    "explanation": "Explication de la réponse correcte"
}
```

### Modifier le Scoring

Ajustez les seuils dans la fonction `submit_quiz()` :

```python
if percentage >= 80:
    level = "Excellent"
elif percentage >= 60:
    level = "Bon"
# etc.
```

## 🎨 Personnalisation du Style

Modifiez `frontend/src/App.css` pour :
- Changer les couleurs de thème
- Adapter le responsive design
- Modifier les animations et transitions

## 🔒 Sécurité et Production

Pour un déploiement en production :

1. **Variables d'environnement** : Configurez les URLs d'API
2. **HTTPS** : Activez SSL/TLS
3. **Base de données** : Remplacez le stockage en mémoire
4. **Authentification** : Ajoutez un système d'auth si nécessaire
5. **Rate limiting** : Limitez les tentatives de quiz

## 🤝 Contributions

N'hésitez pas à contribuer en :
- Ajoutant de nouvelles questions
- Améliorant l'interface utilisateur
- Optimisant les performances
- Corrigeant les bugs

## 📝 Licence

Ce projet est sous licence MIT. Voir le fichier LICENSE pour plus de détails.
